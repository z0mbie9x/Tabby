//
//  APIClient.h
//  Tabby
//
//  Created by Đỗ Tiến Ngọc on 7/18/16.
//  Copyright © 2016 Đỗ Tiến Ngọc. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSUInteger,Category){
    Buildings=0,
    Food,
    Nature,
    People,
    Technology,
    Objects,
};
#define CategoryName(Position) [@[@"buildings",@"food",@"nature",@"people",@"technology",@"objects"] objectAtIndex:Position]
@interface APIClient : NSObject

@end
