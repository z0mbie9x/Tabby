//
//  TabbyLayout.h
//  Tabby
//
//  Created by Đỗ Tiến Ngọc on 7/19/16.
//  Copyright © 2016 Đỗ Tiến Ngọc. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSUInteger,TabbyLayoutStyle){
    TabbyLayoutIcon,
    TabbyLayoutTitle
};

@protocol TabbyLayoutDelegate <NSObject>
@required
-(void) tapLayoutForViewController:(UIViewController *)viewController;
-(void) tapLayoutForViewController:(UIViewController *) viewController index:(NSInteger) index;
@optional
-(NSArray<UIView *> *)buttonStyle:(UIButton *)buttonTab andSperactorStyle:(UIView *) speractorLine;
@end

@interface TabbyLayout : UIViewController<UIScrollViewDelegate>
-(instancetype)initWithFrame:(CGRect)frame inViewController:(UIViewController *)viewController tabBackground:(UIColor *)color addTabArray:(NSArray *)arrayTab withStyle:(TabbyLayoutStyle)style;
@property  UIScrollView *scrollTabView,*scrollContentView;;
@property  NSInteger viewHeight,viewWidth;
@property id<TabbyLayoutDelegate> delegate;
-(void) addTabArray:(NSArray *) arrayTab withStyle:(TabbyLayoutStyle) style;
@end
