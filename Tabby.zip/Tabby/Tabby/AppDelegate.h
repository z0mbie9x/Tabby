//
//  AppDelegate.h
//  Tabby
//
//  Created by Đỗ Tiến Ngọc on 7/15/16.
//  Copyright © 2016 Đỗ Tiến Ngọc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

