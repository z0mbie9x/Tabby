//
//  NotifyCationViewController.m
//  Tabby
//
//  Created by Đỗ Tiến Ngọc on 7/16/16.
//  Copyright © 2016 Đỗ Tiến Ngọc. All rights reserved.
//

#import "NotifyCationViewController.h"

@interface NotifyCationViewController ()

@end

@implementation NotifyCationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
 
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidAppear:(BOOL)animated{
    NSLog(@"Did");
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
