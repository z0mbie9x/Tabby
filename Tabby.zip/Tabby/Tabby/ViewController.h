//
//  ViewController.h
//  Tabby
//
//  Created by Đỗ Tiến Ngọc on 7/15/16.
//  Copyright © 2016 Đỗ Tiến Ngọc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TabLayout.h"
#import "TabbyLayout.h"

@interface ViewController : UIViewController<TabLayoutDelegate,UIScrollViewDelegate,TabbyLayoutDelegate>


@end

